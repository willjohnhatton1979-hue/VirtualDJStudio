import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import DJInterface from './components/DJInterface';
import Header from './components/Header';
import Footer from './components/Footer';
import DesktopMenu from './components/DesktopMenu';
import DistributionPage from './components/DistributionPage';
import InstallerCreator from './components/InstallerCreator';
import { useEffect, useState } from 'react';

const queryClient = new QueryClient();

type ViewMode = 'dj' | 'distribution' | 'installer';

function App() {
  const [isElectron, setIsElectron] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('dj');
  const [expertMode, setExpertMode] = useState(true);

  useEffect(() => {
    const electronCheck = typeof window !== 'undefined' && window.electronAPI !== undefined;
    setIsElectron(electronCheck);

    if (electronCheck && window.electronAPI?.getFullscreenState) {
      window.electronAPI.getFullscreenState().then((state: boolean) => {
        setIsFullscreen(state);
      }).catch(() => {
        setIsFullscreen(false);
      });
    }

    if (electronCheck && window.electronAPI?.onFullscreenChanged) {
      const unsubscribe = window.electronAPI.onFullscreenChanged((state: boolean) => {
        setIsFullscreen(state);
      });
      return unsubscribe;
    }
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F11') {
        e.preventDefault();
        if (window.electronAPI?.toggleFullscreen) {
          window.electronAPI.toggleFullscreen();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleToggleFullscreen = () => {
    if (window.electronAPI?.toggleFullscreen) {
      window.electronAPI.toggleFullscreen();
    }
  };

  const handleSetWindowed = () => {
    if (window.electronAPI?.setWindowedMode) {
      window.electronAPI.setWindowedMode();
    }
  };

  const handleShowInstallerCreator = () => {
    setViewMode(viewMode === 'installer' ? 'dj' : 'installer');
  };

  const handleShowDistribution = () => {
    setViewMode(viewMode === 'distribution' ? 'dj' : 'distribution');
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col bg-background text-foreground">
        {isElectron && (
          <DesktopMenu 
            isFullscreen={isFullscreen}
            onToggleFullscreen={handleToggleFullscreen}
            onSetWindowed={handleSetWindowed}
          />
        )}
        <Header 
          expertMode={expertMode}
          onExpertModeChange={setExpertMode}
          onShowDistribution={handleShowDistribution}
          onShowInstallerCreator={handleShowInstallerCreator}
          isElectron={isElectron}
        />
        <main className="flex-1">
          {viewMode === 'installer' ? (
            <InstallerCreator />
          ) : viewMode === 'distribution' ? (
            <DistributionPage />
          ) : (
            <DJInterface expertMode={expertMode} />
          )}
        </main>
        <Footer />
      </div>
    </QueryClientProvider>
  );
}

export default App;
