export interface BuildProgress {
  status: 'idle' | 'building' | 'success' | 'error';
  message: string;
  progress?: number;
  filePath?: string;
}

export interface ZipProgress {
  status: 'idle' | 'creating' | 'success' | 'error';
  message: string;
  progress?: number;
  filePath?: string;
}

export interface GitHubUploadProgress {
  status: 'idle' | 'uploading' | 'success' | 'error';
  message: string;
  progress?: number;
  releaseUrl?: string;
  version?: string;
  filename?: string;
}

declare global {
  interface Window {
    electronAPI?: {
      toggleFullscreen: () => Promise<void>;
      setWindowedMode: () => Promise<void>;
      getFullscreenState: () => Promise<boolean>;
      onFullscreenChanged: (callback: (isFullscreen: boolean) => void) => () => void;
      buildInstaller: () => Promise<void>;
      onBuildProgress: (callback: (progress: BuildProgress) => void) => () => void;
      openFolder: (filePath: string) => Promise<void>;
      readInstallerFile: (filePath: string) => Promise<Uint8Array>;
      createProjectZip: () => Promise<void>;
      onZipProgress: (callback: (progress: ZipProgress) => void) => () => void;
      readZipFile: (filePath: string) => Promise<Uint8Array>;
      uploadToGitHub: (filePath: string, token: string, repo: string) => Promise<void>;
      onGitHubUploadProgress: (callback: (progress: GitHubUploadProgress) => void) => () => void;
    };
  }
}
