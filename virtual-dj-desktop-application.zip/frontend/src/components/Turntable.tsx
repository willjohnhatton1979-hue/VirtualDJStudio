import { useEffect, useRef } from 'react';

interface TurntableProps {
  isPlaying: boolean;
}

export default function Turntable({ isPlaying }: TurntableProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rotationRef = useRef(0);
  const animationRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(width, height) / 2 - 10;

      // Clear canvas
      ctx.clearRect(0, 0, width, height);

      // Save context
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotationRef.current);

      // Draw vinyl record
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
      gradient.addColorStop(0, 'oklch(0.2 0 0)');
      gradient.addColorStop(0.3, 'oklch(0.15 0 0)');
      gradient.addColorStop(0.7, 'oklch(0.1 0 0)');
      gradient.addColorStop(1, 'oklch(0.05 0 0)');

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, Math.PI * 2);
      ctx.fill();

      // Draw grooves
      ctx.strokeStyle = 'oklch(0.25 0 0 / 0.5)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 20; i++) {
        const r = radius * (0.3 + (i / 20) * 0.6);
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw center label
      ctx.fillStyle = 'oklch(0.7 0.15 280)';
      ctx.beginPath();
      ctx.arc(0, 0, radius * 0.25, 0, Math.PI * 2);
      ctx.fill();

      // Draw center hole
      ctx.fillStyle = 'oklch(0.1 0 0)';
      ctx.beginPath();
      ctx.arc(0, 0, radius * 0.08, 0, Math.PI * 2);
      ctx.fill();

      // Draw marker line
      ctx.strokeStyle = 'oklch(0.9 0.2 50)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -radius * 0.25);
      ctx.lineTo(0, -radius * 0.9);
      ctx.stroke();

      ctx.restore();

      // Update rotation if playing
      if (isPlaying) {
        rotationRef.current += 0.02;
      }

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying]);

  return (
    <div className="flex justify-center">
      <canvas
        ref={canvasRef}
        width={300}
        height={300}
        className="rounded-full shadow-lg"
      />
    </div>
  );
}
