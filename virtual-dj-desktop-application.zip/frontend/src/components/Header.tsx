import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Download, Package } from 'lucide-react';

interface HeaderProps {
  expertMode: boolean;
  onExpertModeChange: (mode: boolean) => void;
  onShowDistribution?: () => void;
  onShowInstallerCreator?: () => void;
  isElectron?: boolean;
}

export default function Header({ 
  expertMode, 
  onExpertModeChange, 
  onShowDistribution,
  onShowInstallerCreator,
  isElectron = false
}: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-8 py-6">
      <div className="container mx-auto flex items-center justify-between">
        <div>
          <h1 className="text-5xl font-bold text-primary mb-2">Virtual DJ Studio</h1>
          <p className="text-muted-foreground text-lg">Professional Dual Deck Mixing Interface</p>
        </div>
        <div className="flex items-center gap-6">
          {isElectron && onShowInstallerCreator && (
            <Button 
              variant="default" 
              size="lg"
              onClick={onShowInstallerCreator}
              className="gap-2"
            >
              <Package className="h-5 w-5" />
              Build Installer
            </Button>
          )}
          {onShowDistribution && (
            <Button 
              variant="default" 
              size="lg"
              onClick={onShowDistribution}
              className="gap-2"
            >
              <Download className="h-5 w-5" />
              Download Options
            </Button>
          )}
          <div className="flex items-center space-x-3">
            <Switch
              id="expert-mode"
              checked={expertMode}
              onCheckedChange={onExpertModeChange}
              className="scale-125"
            />
            <Label htmlFor="expert-mode" className="text-lg font-medium cursor-pointer">
              Expert Mode
            </Label>
          </div>
        </div>
      </div>
    </header>
  );
}
