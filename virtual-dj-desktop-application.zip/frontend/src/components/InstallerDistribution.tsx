import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Download, CheckCircle2, AlertCircle, Loader2, Info, Package, RefreshCw } from 'lucide-react';
import { useGetInstaller } from '../hooks/useQueries';

export default function InstallerDistribution() {
  const { data: installer, isLoading, error, refetch } = useGetInstaller();
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!installer) return;
    
    setIsDownloading(true);
    
    try {
      const directUrl = installer.getDirectURL();
      const link = document.createElement('a');
      link.href = directUrl;
      link.download = 'Virtual-DJ-Studio-Setup-1.0.0.exe';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        setIsDownloading(false);
      }, 100);
    } catch (err) {
      console.error('Download error:', err);
      setIsDownloading(false);
    }
  };

  const handleRefresh = async () => {
    try {
      await refetch();
    } catch (err) {
      console.error('Refetch error:', err);
    }
  };

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-lg text-blue-900 dark:text-blue-100">Windows Installer</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          Professional NSIS installer with automatic Start Menu integration, optional Desktop shortcut, 
          and complete uninstaller functionality. Ready to install on Windows 10/11 (64-bit).
        </AlertDescription>
      </Alert>

      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-3 text-lg">Checking for latest installer...</span>
        </div>
      )}

      {error && (
        <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
          <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
          <AlertTitle className="text-red-900 dark:text-red-100">Error Loading Installer</AlertTitle>
          <AlertDescription className="text-red-800 dark:text-red-200">
            <p className="mb-3">Unable to fetch installer from backend. Please try again.</p>
            <Button variant="outline" size="sm" onClick={handleRefresh} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {!isLoading && !error && installer && (
        <div className="space-y-4">
          <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
            <AlertTitle className="text-green-900 dark:text-green-100">
              ✓ Installer ready for download
            </AlertTitle>
            <AlertDescription className="text-green-800 dark:text-green-200">
              Latest version is available for immediate download.
            </AlertDescription>
          </Alert>

          <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-lg border border-primary/20">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-1">Virtual DJ Studio Setup</h3>
                <p className="text-sm text-muted-foreground">Version 1.0.0 • Windows 10/11 (64-bit) • ~150-200 MB</p>
              </div>
              <Package className="h-12 w-12 text-primary opacity-50" />
            </div>
            
            <Button 
              variant="default" 
              size="lg" 
              className="w-full gap-2 text-lg py-6"
              onClick={handleDownload}
              disabled={isDownloading}
            >
              {isDownloading ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  Starting Download...
                </>
              ) : (
                <>
                  <Download className="h-6 w-6" />
                  Download for Windows 11
                </>
              )}
            </Button>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <p className="font-semibold mb-2">What's Included:</p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Professional NSIS installation wizard</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Automatic Start Menu entry creation</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Optional Desktop shortcut</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Complete uninstaller functionality</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Fullscreen by default with F11 toggle</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>High-DPI display support (4K optimized)</span>
              </li>
            </ul>
          </div>

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">Installation Instructions</AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <ol className="space-y-2 mt-2 list-decimal list-inside">
                <li>Download the installer using the button above</li>
                <li>Run the downloaded .exe file</li>
                <li>Follow the installation wizard</li>
                <li>Choose optional Desktop shortcut</li>
                <li>Launch Virtual DJ Studio from Start Menu</li>
              </ol>
            </AlertDescription>
          </Alert>

          <div className="flex justify-center">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRefresh}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Check for Updates
            </Button>
          </div>
        </div>
      )}

      {!isLoading && !error && !installer && (
        <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
          <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          <AlertTitle className="text-amber-900 dark:text-amber-100">No Installer Available</AlertTitle>
          <AlertDescription className="text-amber-800 dark:text-amber-200">
            <p className="mb-3">The installer has not been uploaded yet. Use the Installer Creator to build and upload the Windows installer.</p>
            <Button variant="outline" size="sm" onClick={handleRefresh} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Check Again
            </Button>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
