import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info, Github, ExternalLink, Copy, CheckCircle2, Terminal, FolderGit2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function RepositoryUpload() {
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  const copyToClipboard = (text: string, commandId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(commandId);
    setTimeout(() => setCopiedCommand(null), 2000);
  };

  const commands = {
    init: 'git init',
    addRemote: 'git remote add origin https://github.com/willjohnhatton1979-hue/VirtualDJStudio.git',
    addFiles: 'git add .',
    commit: 'git commit -m "Initial commit: Virtual DJ Studio complete project"',
    push: 'git push -u origin main',
  };

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-lg text-blue-900 dark:text-blue-100">GitHub Repository Upload</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          Upload the complete Virtual DJ Studio project to your GitHub repository. This includes all source code, 
          configuration files, assets, and documentation.
        </AlertDescription>
      </Alert>

      <Card className="border-primary/20">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Github className="h-8 w-8 text-primary" />
            <div>
              <CardTitle className="text-xl">Repository: willjohnhatton1979-hue/VirtualDJStudio</CardTitle>
              <CardDescription>Complete project synchronization with GitHub</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
            <Info className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            <AlertTitle className="text-amber-900 dark:text-amber-100">Prerequisites</AlertTitle>
            <AlertDescription className="text-amber-800 dark:text-amber-200">
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Git installed on your system</li>
                <li>GitHub account with access to willjohnhatton1979-hue/VirtualDJStudio</li>
                <li>Repository created on GitHub (can be empty)</li>
                <li>GitHub Personal Access Token or SSH key configured</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
              <Terminal className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">Step-by-Step Upload Instructions</h3>
            </div>

            <div className="space-y-3">
              <div className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium mb-1">1. Initialize Git Repository</p>
                    <p className="text-sm text-muted-foreground">Navigate to your project directory and initialize Git</p>
                  </div>
                </div>
                <div className="bg-muted rounded p-3 font-mono text-sm flex items-center justify-between mt-2">
                  <code>{commands.init}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(commands.init, 'init')}
                  >
                    {copiedCommand === 'init' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium mb-1">2. Add Remote Repository</p>
                    <p className="text-sm text-muted-foreground">Link your local repository to GitHub</p>
                  </div>
                </div>
                <div className="bg-muted rounded p-3 font-mono text-sm flex items-center justify-between mt-2">
                  <code className="break-all">{commands.addRemote}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(commands.addRemote, 'addRemote')}
                  >
                    {copiedCommand === 'addRemote' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium mb-1">3. Stage All Files</p>
                    <p className="text-sm text-muted-foreground">Add all project files to Git staging area</p>
                  </div>
                </div>
                <div className="bg-muted rounded p-3 font-mono text-sm flex items-center justify-between mt-2">
                  <code>{commands.addFiles}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(commands.addFiles, 'addFiles')}
                  >
                    {copiedCommand === 'addFiles' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium mb-1">4. Create Initial Commit</p>
                    <p className="text-sm text-muted-foreground">Commit all files with a descriptive message</p>
                  </div>
                </div>
                <div className="bg-muted rounded p-3 font-mono text-sm flex items-center justify-between mt-2">
                  <code className="break-all">{commands.commit}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(commands.commit, 'commit')}
                  >
                    {copiedCommand === 'commit' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium mb-1">5. Push to GitHub</p>
                    <p className="text-sm text-muted-foreground">Upload all files to your GitHub repository</p>
                  </div>
                </div>
                <div className="bg-muted rounded p-3 font-mono text-sm flex items-center justify-between mt-2">
                  <code>{commands.push}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(commands.push, 'push')}
                  >
                    {copiedCommand === 'push' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
            <FolderGit2 className="h-5 w-5 text-green-600 dark:text-green-400" />
            <AlertTitle className="text-green-900 dark:text-green-100">What Gets Uploaded</AlertTitle>
            <AlertDescription className="text-green-800 dark:text-green-200">
              <ul className="space-y-1 mt-2">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Frontend:</strong> React components, hooks, styles, and configuration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Backend:</strong> Motoko canisters and Internet Computer integration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Electron:</strong> Desktop app configuration and main process files</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Assets:</strong> Images, icons, and visual resources</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Documentation:</strong> README, build instructions, and guides</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                  <span><strong>Configuration:</strong> Package.json, Electron Builder, and build scripts</span>
                </li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="flex gap-3">
            <Button
              variant="default"
              size="lg"
              className="flex-1 gap-2"
              onClick={() => window.open('https://github.com/willjohnhatton1979-hue/VirtualDJStudio', '_blank')}
            >
              <ExternalLink className="h-5 w-5" />
              Open Repository on GitHub
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="flex-1 gap-2"
              onClick={() => window.open('https://docs.github.com/en/get-started/importing-your-projects-to-github/importing-source-code-to-github/adding-locally-hosted-code-to-github', '_blank')}
            >
              <Info className="h-5 w-5" />
              GitHub Upload Guide
            </Button>
          </div>

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">Alternative: GitHub Desktop</AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <p className="mb-2">For a visual interface, you can use GitHub Desktop:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Download and install GitHub Desktop</li>
                <li>Add your project folder as a new repository</li>
                <li>Publish to willjohnhatton1979-hue/VirtualDJStudio</li>
              </ol>
              <Button
                variant="outline"
                size="sm"
                className="mt-3 gap-2"
                onClick={() => window.open('https://desktop.github.com/', '_blank')}
              >
                <ExternalLink className="h-4 w-4" />
                Download GitHub Desktop
              </Button>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}
