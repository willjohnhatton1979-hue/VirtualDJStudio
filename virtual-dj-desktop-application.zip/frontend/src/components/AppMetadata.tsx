/**
 * Application metadata component for branding and installer information.
 * This component is not rendered but provides metadata used during packaging.
 */

export const APP_METADATA = {
  name: 'Virtual DJ Studio',
  version: '1.0.0',
  description: 'Professional Virtual DJ Desktop Application for Windows 11 with dual turntables, mixer, and real-time audio processing',
  author: 'Built with caffeine.ai',
  productName: 'Virtual DJ Studio',
  appId: 'com.virtualdj.studio',
  copyright: '© 2025. Built with love using caffeine.ai',
  
  // Installer configuration
  installer: {
    createDesktopShortcut: true,
    createStartMenuShortcut: true,
    allowToChangeInstallationDirectory: true,
    oneClick: false,
    shortcutName: 'Virtual DJ Studio',
    language: 'English',
  },
  
  // Window configuration
  window: {
    defaultWidth: 1920,
    defaultHeight: 1080,
    fullscreenByDefault: true,
    resizable: true,
    minWidth: 1280,
    minHeight: 720,
    highDpiSupport: true,
    optimizedFor4K: true,
  },
  
  // Features
  features: [
    'Dual turntable interface (Deck A & Deck B)',
    'Professional central mixer with crossfader',
    'Real-time waveform visualization',
    '3-band EQ controls per deck',
    'Cue points and looping functionality',
    'Tempo and pitch adjustment',
    'VU meters with real-time audio levels',
    'Expert and Basic mode toggle',
    'Fullscreen and windowed mode support (F11)',
    'MP3 and WAV audio file support',
    'High-DPI and 4K display optimization',
    'Native Windows 11 desktop integration',
  ],
  
  // Technical specifications
  technical: {
    platform: 'Windows 11',
    architecture: 'x64',
    framework: 'Electron',
    frontend: 'React + TypeScript',
    audioEngine: 'Web Audio API',
    installer: 'NSIS',
    updateSupport: true,
    modularArchitecture: true,
  },
};

export default function AppMetadata() {
  return null; // This component doesn't render anything
}
