import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ExternalLink, CheckCircle2, AlertCircle, Loader2, Info, Github, Upload, Key } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useGetGitHubReleases, useUploadGitHubRelease } from '../hooks/useQueries';
import type { GitHubUploadProgress } from '../types/electron';

export default function GitHubDistribution() {
  const { data: releases, isLoading, error, refetch } = useGetGitHubReleases();
  const uploadRelease = useUploadGitHubRelease();
  const [githubToken, setGithubToken] = useState('');
  const [githubRepo, setGithubRepo] = useState('willjohnhatton1979-hue/VirtualDJStudio');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<GitHubUploadProgress>({
    status: 'idle',
    message: '',
  });

  const handleUploadToGitHub = useCallback(async (releaseUrl: string, version: bigint, filename: string) => {
    try {
      await uploadRelease.mutateAsync({ releaseUrl, version, filename });
      await refetch();
    } catch (error) {
      console.error('GitHub release save error:', error);
    }
  }, [uploadRelease, refetch]);

  useEffect(() => {
    if (window.electronAPI?.onGitHubUploadProgress) {
      const unsubscribe = window.electronAPI.onGitHubUploadProgress((progress) => {
        setUploadProgress(progress);
        setIsUploading(progress.status === 'uploading');
        
        if (progress.status === 'success' && progress.releaseUrl && progress.version && progress.filename) {
          handleUploadToGitHub(progress.releaseUrl, BigInt(progress.version), progress.filename).catch((err) => {
            console.error('Auto-save release error:', err);
          });
        }
      });
      return unsubscribe;
    }
  }, [handleUploadToGitHub]);

  const handleStartUpload = async () => {
    if (!githubToken.trim()) {
      alert('Please enter your GitHub Personal Access Token');
      return;
    }

    if (!githubRepo.trim()) {
      alert('Please enter the GitHub repository (owner/repo)');
      return;
    }

    if (!window.electronAPI?.uploadToGitHub) {
      setUploadProgress({
        status: 'error',
        message: 'GitHub upload not available - please run in Electron desktop app',
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress({
      status: 'uploading',
      message: 'Starting GitHub upload...',
    });

    try {
      await window.electronAPI.uploadToGitHub('', githubToken, githubRepo);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('GitHub upload error:', errorMessage);
      setUploadProgress({
        status: 'error',
        message: `Upload failed: ${errorMessage}`,
      });
      setIsUploading(false);
    }
  };

  const handleRefresh = async () => {
    try {
      await refetch();
    } catch (err) {
      console.error('Refetch error:', err);
    }
  };

  const handleOpenRelease = (metadata: { description: string }) => {
    try {
      const urlMatch = metadata.description.match(/https:\/\/github\.com\/[^\s]+/);
      if (urlMatch) {
        window.open(urlMatch[0], '_blank');
      }
    } catch (err) {
      console.error('Open release error:', err);
    }
  };

  const isElectron = typeof window !== 'undefined' && window.electronAPI !== undefined;

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-lg text-blue-900 dark:text-blue-100">GitHub Releases</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          External hosting via GitHub Releases provides public CDN-backed downloads with version management. 
          Automatically uploads installer .exe files to your configured GitHub repository.
        </AlertDescription>
      </Alert>

      {uploadProgress.status !== 'idle' && (
        <Alert
          variant={uploadProgress.status === 'error' ? 'destructive' : 'default'}
          className={
            uploadProgress.status === 'success'
              ? 'border-green-500 bg-green-50 dark:bg-green-950'
              : ''
          }
        >
          {uploadProgress.status === 'uploading' && (
            <Loader2 className="h-5 w-5 animate-spin" />
          )}
          {uploadProgress.status === 'success' && (
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          )}
          {uploadProgress.status === 'error' && (
            <AlertCircle className="h-5 w-5" />
          )}
          <AlertDescription className="ml-2 text-base">
            {uploadProgress.message}
          </AlertDescription>
        </Alert>
      )}

      {isUploading && uploadProgress.progress !== undefined && (
        <div className="space-y-2">
          <Progress value={uploadProgress.progress} className="h-3" />
          <p className="text-sm text-muted-foreground text-center">
            Uploading to GitHub... {uploadProgress.progress}%
          </p>
        </div>
      )}

      {isElectron && (
        <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-lg border border-primary/20 space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold mb-1">Upload to GitHub Releases</h3>
              <p className="text-sm text-muted-foreground">Automatically create release and upload installer</p>
            </div>
            <Github className="h-12 w-12 text-primary opacity-50" />
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium mb-1 flex items-center gap-2">
                <Key className="h-4 w-4" />
                GitHub Personal Access Token
              </label>
              <Input
                type="password"
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                value={githubToken}
                onChange={(e) => setGithubToken(e.target.value)}
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Required scopes: <code className="bg-background px-1 rounded">repo</code>
              </p>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 flex items-center gap-2">
                <Github className="h-4 w-4" />
                Repository (owner/repo)
              </label>
              <Input
                type="text"
                placeholder="willjohnhatton1979-hue/VirtualDJStudio"
                value={githubRepo}
                onChange={(e) => setGithubRepo(e.target.value)}
              />
            </div>
          </div>
          
          <Button 
            variant="default" 
            size="lg" 
            className="w-full gap-2 text-lg py-6"
            onClick={handleStartUpload}
            disabled={isUploading || !githubToken.trim() || !githubRepo.trim()}
          >
            {isUploading ? (
              <>
                <Loader2 className="h-6 w-6 animate-spin" />
                Uploading to GitHub...
              </>
            ) : (
              <>
                <Upload className="h-6 w-6" />
                Upload Installer to GitHub
              </>
            )}
          </Button>

          <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
            <Info className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            <AlertTitle className="text-amber-900 dark:text-amber-100">Setup Instructions</AlertTitle>
            <AlertDescription className="text-amber-800 dark:text-amber-200 space-y-2">
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>Create a GitHub Personal Access Token at github.com/settings/tokens</li>
                <li>Grant <code className="bg-background px-1 rounded">repo</code> scope for full repository access</li>
                <li>Enter the token and repository name above</li>
                <li>Click "Upload Installer to GitHub" to create a release</li>
              </ol>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-3 text-lg">Loading GitHub releases...</span>
        </div>
      )}

      {error && (
        <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
          <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
          <AlertTitle className="text-red-900 dark:text-red-100">Error Loading Releases</AlertTitle>
          <AlertDescription className="text-red-800 dark:text-red-200">
            <p className="mb-3">Unable to fetch GitHub releases from backend. Please try again.</p>
            <Button variant="outline" size="sm" onClick={handleRefresh}>
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {!isLoading && !error && (
        <>
          {releases && releases.length > 0 ? (
            <div className="space-y-4">
              <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
                <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-900 dark:text-green-100">
                  {releases.length} GitHub Release{releases.length !== 1 ? 's' : ''} Available
                </AlertTitle>
                <AlertDescription className="text-green-800 dark:text-green-200">
                  Public download links hosted on GitHub's CDN
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                {releases.map(([id, metadata]) => (
                  <div
                    key={id.toString()}
                    className="bg-gradient-to-r from-primary/10 to-primary/5 p-4 rounded-lg border border-primary/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Github className="h-5 w-5 text-primary" />
                        <span className="font-semibold">{metadata.title}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(Number(metadata.timestamp) / 1000000).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{metadata.description}</p>
                    <Button
                      variant="default"
                      size="sm"
                      className="w-full gap-2"
                      onClick={() => handleOpenRelease(metadata)}
                    >
                      <ExternalLink className="h-4 w-4" />
                      Open GitHub Release
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
              <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              <AlertTitle className="text-amber-900 dark:text-amber-100">No Releases Yet</AlertTitle>
              <AlertDescription className="text-amber-800 dark:text-amber-200">
                <p className="mb-3">No GitHub releases have been uploaded yet. {isElectron ? 'Use the form above to upload your first release.' : 'Upload releases from the Electron desktop app.'}</p>
                <Button variant="outline" size="sm" onClick={handleRefresh}>
                  Check Again
                </Button>
              </AlertDescription>
            </Alert>
          )}

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">External Hosting Benefits</AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <ul className="space-y-2 mt-2">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Automatic .exe upload to configured GitHub repository</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Verified public download link generation</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>CDN-backed downloads through GitHub infrastructure</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Version management and release notes support</span>
                </li>
              </ul>
            </AlertDescription>
          </Alert>
        </>
      )}
    </div>
  );
}
