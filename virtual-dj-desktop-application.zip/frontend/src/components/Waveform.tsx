import { useEffect, useRef, useState } from 'react';
import { AudioEngine } from '../lib/audioEngine';

interface WaveformProps {
  audioEngine: AudioEngine;
  deckId: 'A' | 'B';
  progress: number;
  duration: number;
  cuePoints: number[];
  loopStart: number | null;
  loopEnd: number | null;
  onSeek: (time: number) => void;
}

export default function Waveform({
  audioEngine,
  deckId,
  progress,
  duration,
  cuePoints,
  loopStart,
  loopEnd,
  onSeek,
}: WaveformProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [waveformData, setWaveformData] = useState<number[]>([]);

  useEffect(() => {
    const deck = audioEngine.getDeck(deckId);
    if (deck.audioBuffer) {
      const data = deck.audioBuffer.getChannelData(0);
      const samples = 200;
      const blockSize = Math.floor(data.length / samples);
      const filteredData: number[] = [];

      for (let i = 0; i < samples; i++) {
        let sum = 0;
        for (let j = 0; j < blockSize; j++) {
          sum += Math.abs(data[i * blockSize + j]);
        }
        filteredData.push(sum / blockSize);
      }

      setWaveformData(filteredData);
    }
  }, [audioEngine, deckId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || waveformData.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const barWidth = width / waveformData.length;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw waveform
    waveformData.forEach((value, index) => {
      const barHeight = value * height * 2;
      const x = index * barWidth;
      const y = (height - barHeight) / 2;

      // Color based on progress
      const progressRatio = duration > 0 ? progress / duration : 0;
      const isPassed = index / waveformData.length < progressRatio;

      ctx.fillStyle = isPassed
        ? 'oklch(0.7 0.2 280)'
        : 'oklch(0.5 0.1 280 / 0.5)';
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    });

    // Draw loop region
    if (loopStart !== null && loopEnd !== null && duration > 0) {
      const startX = (loopStart / duration) * width;
      const endX = (loopEnd / duration) * width;
      ctx.fillStyle = 'oklch(0.6 0.2 120 / 0.2)';
      ctx.fillRect(startX, 0, endX - startX, height);
    }

    // Draw cue points
    cuePoints.forEach((cueTime) => {
      if (duration > 0) {
        const x = (cueTime / duration) * width;
        ctx.fillStyle = 'oklch(0.7 0.25 50)';
        ctx.fillRect(x - 1, 0, 2, height);
      }
    });

    // Draw progress line
    if (duration > 0) {
      const progressX = (progress / duration) * width;
      ctx.strokeStyle = 'oklch(0.9 0.2 50)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(progressX, 0);
      ctx.lineTo(progressX, height);
      ctx.stroke();
    }
  }, [waveformData, progress, duration, cuePoints, loopStart, loopEnd]);

  const handleClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (duration === 0) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const ratio = x / rect.width;
    const time = ratio * duration;

    onSeek(time);
  };

  return (
    <div className="rounded-lg bg-muted/30 p-2">
      <canvas
        ref={canvasRef}
        width={600}
        height={80}
        onClick={handleClick}
        className="w-full cursor-pointer rounded"
      />
    </div>
  );
}
