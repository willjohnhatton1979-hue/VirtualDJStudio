import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import InstallerDistribution from './InstallerDistribution';
import ZipDistribution from './ZipDistribution';
import GitHubDistribution from './GitHubDistribution';
import RepositoryUpload from './RepositoryUpload';
import { Package, Github, Upload, FolderGit2 } from 'lucide-react';

export default function DistributionPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Distribution Options
        </h1>
        <p className="text-lg text-muted-foreground">
          Choose how you want to distribute Virtual DJ Studio
        </p>
      </div>

      <Tabs defaultValue="installer" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="installer" className="gap-2">
            <Package className="h-4 w-4" />
            Windows Installer
          </TabsTrigger>
          <TabsTrigger value="zip" className="gap-2">
            <Upload className="h-4 w-4" />
            Project ZIP
          </TabsTrigger>
          <TabsTrigger value="github" className="gap-2">
            <Github className="h-4 w-4" />
            GitHub Releases
          </TabsTrigger>
          <TabsTrigger value="repository" className="gap-2">
            <FolderGit2 className="h-4 w-4" />
            Repository Upload
          </TabsTrigger>
        </TabsList>

        <TabsContent value="installer" className="space-y-6">
          <InstallerDistribution />
        </TabsContent>

        <TabsContent value="zip" className="space-y-6">
          <ZipDistribution />
        </TabsContent>

        <TabsContent value="github" className="space-y-6">
          <GitHubDistribution />
        </TabsContent>

        <TabsContent value="repository" className="space-y-6">
          <RepositoryUpload />
        </TabsContent>
      </Tabs>
    </div>
  );
}
