import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Package, FolderOpen, CheckCircle2, AlertCircle, Loader2, Info, Upload } from 'lucide-react';
import type { BuildProgress } from '../types/electron';
import { useUploadInstaller } from '../hooks/useQueries';
import { ExternalBlob } from '../backend';

export default function InstallerCreator() {
  const [buildProgress, setBuildProgress] = useState<BuildProgress>({
    status: 'idle',
    message: '',
  });
  const [isBuilding, setIsBuilding] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [builtFilePath, setBuiltFilePath] = useState<string | null>(null);
  const uploadInstaller = useUploadInstaller();

  const handleUploadInstaller = useCallback(async (filePath: string) => {
    setIsUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    setUploadSuccess(false);
    
    try {
      setBuildProgress({
        status: 'building',
        message: 'Reading installer file...',
        filePath,
      });

      if (!window.electronAPI?.readInstallerFile) {
        throw new Error('File reading not available - please run in Electron desktop app');
      }

      const bytes = await window.electronAPI.readInstallerFile(filePath);
      
      if (!bytes || bytes.length === 0) {
        throw new Error('Failed to read installer file - file is empty');
      }

      const fileSizeMB = (bytes.length / 1024 / 1024).toFixed(2);

      setBuildProgress({
        status: 'building',
        message: `Preparing upload (${fileSizeMB} MB)...`,
        filePath,
      });
      
      const arrayBuffer = new ArrayBuffer(bytes.length);
      const uint8Array = new Uint8Array(arrayBuffer);
      uint8Array.set(new Uint8Array(bytes));
      
      const blob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
        setUploadProgress(percentage);
        setBuildProgress({
          status: 'building',
          message: `Uploading to backend: ${percentage}%`,
          filePath,
        });
      });
      
      setBuildProgress({
        status: 'building',
        message: 'Uploading to backend...',
        filePath,
      });
      
      await uploadInstaller.mutateAsync(blob);
      
      setUploadSuccess(true);
      setUploadProgress(100);
      
      setBuildProgress({
        status: 'success',
        message: '✓ Installer ready for download',
        filePath,
      });
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error during upload';
      console.error('Installer upload error:', errorMessage);
      setUploadError(errorMessage);
      
      setBuildProgress({
        status: 'error',
        message: `Upload failed: ${errorMessage}`,
        filePath,
      });
    } finally {
      setIsUploading(false);
    }
  }, [uploadInstaller]);

  useEffect(() => {
    if (window.electronAPI?.onBuildProgress) {
      const unsubscribe = window.electronAPI.onBuildProgress((progress) => {
        setBuildProgress(progress);
        setIsBuilding(progress.status === 'building');
        
        if (progress.status === 'success' && progress.filePath && !isUploading && !uploadSuccess) {
          setBuiltFilePath(progress.filePath);
          handleUploadInstaller(progress.filePath).catch((err) => {
            console.error('Auto-upload error:', err);
          });
        }
      });
      return unsubscribe;
    }
  }, [handleUploadInstaller, isUploading, uploadSuccess]);

  const handleBuildInstaller = async () => {
    if (!window.electronAPI?.buildInstaller) {
      setBuildProgress({
        status: 'error',
        message: 'Build functionality not available - please run in Electron desktop app',
      });
      return;
    }
    
    setIsBuilding(true);
    setUploadProgress(0);
    setUploadError(null);
    setUploadSuccess(false);
    setBuiltFilePath(null);
    
    setBuildProgress({
      status: 'building',
      message: 'Starting build process...',
    });

    try {
      await window.electronAPI.buildInstaller();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('Build error:', errorMessage);
      setBuildProgress({
        status: 'error',
        message: `Build failed: ${errorMessage}`,
      });
      setIsBuilding(false);
    }
  };

  const handleRetryUpload = async () => {
    if (builtFilePath || buildProgress.filePath) {
      const pathToUse = builtFilePath || buildProgress.filePath!;
      try {
        await handleUploadInstaller(pathToUse);
      } catch (err) {
        console.error('Retry upload error:', err);
      }
    } else {
      setUploadError('No file path available. Please rebuild the installer.');
    }
  };

  const handleOpenFolder = async () => {
    if (buildProgress.filePath && window.electronAPI?.openFolder) {
      try {
        await window.electronAPI.openFolder(buildProgress.filePath);
      } catch (error) {
        console.error('Open folder error:', error);
      }
    }
  };

  return (
    <div className="container mx-auto px-8 py-12 max-w-4xl">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl flex items-center gap-3">
            <Package className="h-8 w-8 text-primary" />
            Automated Installer Builder
          </CardTitle>
          <CardDescription className="text-lg mt-2">
            Generate a ready-to-download Windows 11 installer (.exe) with automatic packaging and backend upload.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {buildProgress.status !== 'idle' && (
            <Alert
              variant={
                buildProgress.status === 'error'
                  ? 'destructive'
                  : buildProgress.status === 'success' && uploadSuccess
                  ? 'default'
                  : 'default'
              }
              className={
                buildProgress.status === 'success' && uploadSuccess
                  ? 'border-green-500 bg-green-50 dark:bg-green-950'
                  : ''
              }
            >
              {(buildProgress.status === 'building' || isUploading) && (
                <Loader2 className="h-5 w-5 animate-spin" />
              )}
              {buildProgress.status === 'success' && uploadSuccess && (
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              )}
              {buildProgress.status === 'error' && (
                <AlertCircle className="h-5 w-5" />
              )}
              <AlertDescription className="ml-2 text-base">
                {buildProgress.message}
              </AlertDescription>
            </Alert>
          )}

          {(isBuilding || isUploading) && (
            <div className="space-y-2">
              <Progress 
                value={isUploading ? uploadProgress : undefined} 
                className="h-3" 
              />
              <p className="text-sm text-muted-foreground text-center">
                {isUploading 
                  ? `Uploading installer to backend... ${uploadProgress}%` 
                  : 'Building installer... This may take 2-5 minutes.'}
              </p>
            </div>
          )}

          {uploadError && buildProgress.status === 'error' && (
            <Alert variant="destructive">
              <AlertCircle className="h-5 w-5" />
              <AlertTitle>Upload Failed</AlertTitle>
              <AlertDescription className="space-y-3">
                <p className="text-sm font-semibold">{uploadError}</p>
                <p className="text-xs">
                  The installer was built successfully and is available locally. 
                  You can retry the upload or distribute the local file manually.
                </p>
                <Button
                  onClick={handleRetryUpload}
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  disabled={isUploading}
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Retrying...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4" />
                      Retry Upload
                    </>
                  )}
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {buildProgress.status === 'success' && buildProgress.filePath && uploadSuccess && (
            <div className="space-y-4">
              <Alert className="border-green-500 bg-green-50 dark:bg-green-950 shadow-md">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-900 dark:text-green-100 text-lg">
                  ✓ Installer ready for download
                </AlertTitle>
                <AlertDescription className="text-green-800 dark:text-green-200 space-y-3">
                  <div className="space-y-2">
                    <p className="font-semibold flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4" />
                      Upload complete - installer is now available for download
                    </p>
                    <ul className="text-sm space-y-1 ml-6">
                      <li>✓ Installer uploaded successfully to backend storage</li>
                      <li>✓ Download page will show the installer immediately</li>
                      <li>✓ Users can download with a direct, working link</li>
                      <li>✓ File is securely hosted and accessible</li>
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>

              <div className="bg-muted p-4 rounded-lg space-y-3">
                <p className="font-semibold text-lg flex items-center gap-2">
                  <Info className="h-5 w-5 text-blue-600" />
                  Local Copy Available:
                </p>
                <code className="block bg-background p-3 rounded border text-sm break-all">
                  {buildProgress.filePath}
                </code>
                <Button
                  onClick={handleOpenFolder}
                  variant="default"
                  size="lg"
                  className="w-full gap-2"
                >
                  <FolderOpen className="h-5 w-5" />
                  Open Folder in File Explorer
                </Button>
                <p className="text-xs text-muted-foreground">
                  The installer is also saved locally for manual distribution or backup.
                </p>
              </div>
            </div>
          )}

          {buildProgress.status === 'error' && buildProgress.filePath && !uploadSuccess && (
            <div className="bg-muted p-4 rounded-lg space-y-3">
              <p className="font-semibold text-lg flex items-center gap-2">
                <Info className="h-5 w-5 text-amber-600" />
                Installer Built Locally:
              </p>
              <code className="block bg-background p-3 rounded border text-sm break-all">
                {buildProgress.filePath}
              </code>
              <Button
                onClick={handleOpenFolder}
                variant="outline"
                size="lg"
                className="w-full gap-2"
              >
                <FolderOpen className="h-5 w-5" />
                Open Folder in File Explorer
              </Button>
              <p className="text-xs text-muted-foreground">
                The installer file is available locally and can be distributed manually.
              </p>
            </div>
          )}

          <div className="pt-4">
            <Button
              onClick={handleBuildInstaller}
              disabled={isBuilding || isUploading}
              size="lg"
              className="w-full text-lg py-6 gap-3"
            >
              {isBuilding || isUploading ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  {isUploading ? 'Uploading...' : 'Building Installer...'}
                </>
              ) : (
                <>
                  <Package className="h-6 w-6" />
                  Generate & Upload Windows Installer
                </>
              )}
            </Button>
          </div>

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">
              Automatic Build & Upload Process
            </AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <ul className="space-y-2 mt-2">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 1:</strong> Frontend is built and optimized for production</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 2:</strong> Electron Builder packages with all assets and branding</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 3:</strong> NSIS installer created with icon and banner</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 4:</strong> Installer uploaded to secure backend storage</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 5:</strong> Direct download link becomes available immediately</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Step 6:</strong> Download page automatically updates with working link</span>
                </li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="bg-muted p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Installer Features:</h3>
            <ul className="text-sm space-y-1 text-muted-foreground">
              <li>• Professional NSIS installation wizard</li>
              <li>• Automatic Start Menu entry creation</li>
              <li>• Optional Desktop shortcut during installation</li>
              <li>• Complete uninstaller functionality</li>
              <li>• Application launches in fullscreen by default</li>
              <li>• F11 keyboard shortcut for fullscreen toggle</li>
              <li>• Full window resizing capability</li>
              <li>• High-DPI display support (4K optimized)</li>
              <li>• Secure backend storage with direct download URLs</li>
              <li>• Binary data handling for large files (150-200 MB)</li>
              <li>• English language throughout</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
