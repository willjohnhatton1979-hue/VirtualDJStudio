import { useState } from 'react';
import Deck from './Deck';
import Mixer from './Mixer';
import { AudioEngine } from '../lib/audioEngine';

interface DJInterfaceProps {
  expertMode: boolean;
}

export default function DJInterface({ expertMode }: DJInterfaceProps) {
  const [audioEngine] = useState(() => new AudioEngine());

  return (
    <div className="container mx-auto px-6 py-10">
      {/* Desktop-optimized layout with proper spacing for fullscreen viewing */}
      <div className="flex flex-col gap-8 xl:grid xl:grid-cols-[1fr_auto_1fr] xl:items-start xl:gap-10">
        {/* Left Deck - Deck A */}
        <div className="w-full">
          <Deck
            deckId="A"
            audioEngine={audioEngine}
            expertMode={expertMode}
          />
        </div>

        {/* Center Mixer - optimized width for desktop */}
        <div className="w-full xl:w-auto xl:min-w-[360px]">
          <Mixer audioEngine={audioEngine} expertMode={expertMode} />
        </div>

        {/* Right Deck - Deck B */}
        <div className="w-full">
          <Deck
            deckId="B"
            audioEngine={audioEngine}
            expertMode={expertMode}
          />
        </div>
      </div>
    </div>
  );
}
