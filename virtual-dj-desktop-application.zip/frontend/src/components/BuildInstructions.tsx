import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Download, Terminal, CheckCircle, AlertCircle, ExternalLink, Package } from 'lucide-react';

export function BuildInstructions() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Generate Windows 11 Installer</h1>
        <p className="text-muted-foreground">
          Create a downloadable .exe installer for Virtual DJ Studio with NSIS wizard, app icon, and banner assets
        </p>
      </div>

      <Alert className="mb-6 border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Package className="h-4 w-4 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-blue-900 dark:text-blue-100">Ready to Build</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          All configuration files are in place. The electron-builder.json includes your app icon 
          (virtual-dj-studio-icon-transparent.png) and installer banner (installer-banner.png) from 
          the generated/ folder. Follow the steps below to create your Windows installer.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Step 1: Prerequisites
            </CardTitle>
            <CardDescription>Ensure your system is ready for building</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="mb-2 font-medium">Required Software:</p>
              <ul className="list-disc list-inside space-y-2 text-sm ml-4">
                <li>Windows 11 (or Windows 10)</li>
                <li>Node.js 18+ and npm</li>
                <li>Git (optional, for version control)</li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-medium">Download Node.js:</p>
              <Button variant="outline" asChild>
                <a href="https://nodejs.org" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  nodejs.org
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Step 2: Install Dependencies
            </CardTitle>
            <CardDescription>Install all required npm packages</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto">
              <code>{`# Navigate to project root
cd virtual-dj-studio

# Install root dependencies (Electron, electron-builder)
npm install

# Install frontend dependencies (React, Vite, etc.)
cd frontend
npm install
cd ..`}</code>
            </pre>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Step 3: Build Frontend
            </CardTitle>
            <CardDescription>Create optimized production build</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto">
              <code>{`# Build the React frontend
cd frontend
npm run build
cd ..`}</code>
            </pre>
            <p className="mt-2 text-sm text-muted-foreground">
              This creates the production build in <code className="bg-muted px-1 py-0.5 rounded">frontend/dist/</code>
            </p>
          </CardContent>
        </Card>

        <Card className="border-green-500 bg-green-50 dark:bg-green-950">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-900 dark:text-green-100">
              <Download className="h-5 w-5" />
              Step 4: Generate Windows Installer
            </CardTitle>
            <CardDescription className="text-green-800 dark:text-green-200">
              Create the .exe installer with electron-builder
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto">
              <code>{`# From project root directory
npm run build:win`}</code>
            </pre>
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertTitle>Build Output Location</AlertTitle>
              <AlertDescription>
                The installer will be created at:
                <pre className="bg-muted p-3 rounded-lg mt-2 text-xs">
                  <code>dist-electron/Virtual DJ Studio Setup 1.0.0.exe</code>
                </pre>
              </AlertDescription>
            </Alert>
            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
              <p className="font-medium text-blue-900 dark:text-blue-100 mb-2">Installer Features:</p>
              <ul className="list-disc list-inside space-y-1 text-sm text-blue-800 dark:text-blue-200">
                <li>Standard NSIS installation wizard</li>
                <li>Custom app icon (256x256 transparent PNG)</li>
                <li>Professional installer banner (600x150)</li>
                <li>Product name: "Virtual DJ Studio"</li>
                <li>Version: 1.0.0 (with auto-update support)</li>
                <li>Desktop shortcut option</li>
                <li>Start Menu integration</li>
                <li>Fullscreen by default, resizable window</li>
                <li>Complete uninstaller included</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              Step 5: Test the Installer
            </CardTitle>
            <CardDescription>Verify the installer works correctly</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ol className="list-decimal list-inside space-y-2 text-sm ml-4">
              <li>Locate the .exe file in <code className="bg-muted px-1 py-0.5 rounded">dist-electron/</code></li>
              <li>Double-click to run the installer</li>
              <li>Follow the NSIS installation wizard</li>
              <li>Choose installation location and shortcuts</li>
              <li>Launch Virtual DJ Studio from Start Menu or Desktop</li>
              <li>Verify fullscreen mode and all features work</li>
              <li>Test window resizing and F11 toggle</li>
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ExternalLink className="h-5 w-5" />
              Step 6: Distribute the Installer
            </CardTitle>
            <CardDescription>Share the .exe with users via download link</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="font-medium mb-2">Recommended Distribution Methods:</p>
              <div className="space-y-3">
                <div className="border rounded-lg p-3">
                  <p className="font-medium text-sm">GitHub Releases (Recommended)</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Create a release, upload the .exe, and get a permanent download link
                  </p>
                  <Button variant="outline" size="sm" className="mt-2" asChild>
                    <a href="https://docs.github.com/en/repositories/releasing-projects-on-github" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-2" />
                      GitHub Releases Guide
                    </a>
                  </Button>
                </div>
                <div className="border rounded-lg p-3">
                  <p className="font-medium text-sm">Cloud Storage</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Upload to Google Drive, Dropbox, OneDrive, or Mega and share the link
                  </p>
                </div>
                <div className="border rounded-lg p-3">
                  <p className="font-medium text-sm">Your Own Website</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Host on your web server with a direct download link
                  </p>
                </div>
                <div className="border rounded-lg p-3">
                  <p className="font-medium text-sm">File Transfer Services</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Use WeTransfer, SendGB, or similar for temporary sharing
                  </p>
                </div>
              </div>
            </div>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>File Size Note</AlertTitle>
              <AlertDescription>
                The installer will be approximately 100-150 MB due to Electron and Chromium dependencies.
                Ensure your hosting service supports files of this size.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Future Updates</CardTitle>
            <CardDescription>How to release new versions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm">To release an updated version:</p>
            <ol className="list-decimal list-inside space-y-2 text-sm ml-4">
              <li>Update version in <code className="bg-muted px-1 py-0.5 rounded">package.json</code> and <code className="bg-muted px-1 py-0.5 rounded">electron-builder.json</code></li>
              <li>Make your code changes</li>
              <li>Run <code className="bg-muted px-1 py-0.5 rounded">npm run build:win</code> again</li>
              <li>Distribute the new installer</li>
            </ol>
            <p className="text-xs text-muted-foreground mt-3">
              The electron-builder configuration includes automatic update support for future versions.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Additional Documentation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start" asChild>
              <a href="/BUILD_INSTRUCTIONS.md" target="_blank">
                <ExternalLink className="h-4 w-4 mr-2" />
                Complete Build Instructions (Markdown)
              </a>
            </Button>
            <Button variant="outline" className="w-full justify-start" asChild>
              <a href="/PACKAGING_GUIDE.md" target="_blank">
                <ExternalLink className="h-4 w-4 mr-2" />
                Detailed Packaging Guide
              </a>
            </Button>
            <Button variant="outline" className="w-full justify-start" asChild>
              <a href="/README.md" target="_blank">
                <ExternalLink className="h-4 w-4 mr-2" />
                User Documentation
              </a>
            </Button>
          </CardContent>
        </Card>

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Troubleshooting</AlertTitle>
          <AlertDescription>
            <p className="mb-2">Common issues and solutions:</p>
            <ul className="list-disc list-inside space-y-1 text-sm ml-4">
              <li><strong>Build fails:</strong> Ensure all dependencies are installed with <code className="bg-muted px-1 py-0.5 rounded">npm install</code></li>
              <li><strong>Missing assets:</strong> Verify icon and banner files exist in <code className="bg-muted px-1 py-0.5 rounded">generated/</code> folder</li>
              <li><strong>Installer won't run:</strong> Check Windows Defender/antivirus settings</li>
              <li><strong>App won't start:</strong> Try running installer as administrator</li>
            </ul>
            <p className="mt-3 text-sm">
              For more help, visit{' '}
              <a
                href="https://caffeine.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-medium"
              >
                caffeine.ai
              </a>
            </p>
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}
