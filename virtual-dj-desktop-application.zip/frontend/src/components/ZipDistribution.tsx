import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Download, CheckCircle2, AlertCircle, Loader2, Info, FileArchive, Terminal, Package } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useGetZip, useUploadZip } from '../hooks/useQueries';
import { ExternalBlob } from '../backend';
import type { ZipProgress } from '../types/electron';

export default function ZipDistribution() {
  const { data: zipFile, isLoading, error, refetch } = useGetZip();
  const uploadZip = useUploadZip();
  const [isDownloading, setIsDownloading] = useState(false);
  const [zipProgress, setZipProgress] = useState<ZipProgress>({
    status: 'idle',
    message: '',
  });
  const [isCreating, setIsCreating] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [builtZipPath, setBuiltZipPath] = useState<string | null>(null);

  const handleUploadZip = useCallback(async (filePath: string) => {
    setIsUploading(true);
    setUploadProgress(0);
    setUploadSuccess(false);
    
    try {
      setZipProgress({
        status: 'creating',
        message: 'Reading ZIP file...',
        filePath,
      });

      if (!window.electronAPI?.readZipFile) {
        throw new Error('File reading not available - please run in Electron desktop app');
      }

      const bytes = await window.electronAPI.readZipFile(filePath);
      
      if (!bytes || bytes.length === 0) {
        throw new Error('Failed to read ZIP file - file is empty');
      }

      const fileSizeMB = (bytes.length / 1024 / 1024).toFixed(2);

      setZipProgress({
        status: 'creating',
        message: `Preparing upload (${fileSizeMB} MB)...`,
        filePath,
      });
      
      const arrayBuffer = new ArrayBuffer(bytes.length);
      const uint8Array = new Uint8Array(arrayBuffer);
      uint8Array.set(new Uint8Array(bytes));
      
      const blob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
        setUploadProgress(percentage);
        setZipProgress({
          status: 'creating',
          message: `Uploading to backend: ${percentage}%`,
          filePath,
        });
      });
      
      setZipProgress({
        status: 'creating',
        message: 'Uploading to backend...',
        filePath,
      });
      
      await uploadZip.mutateAsync(blob);
      
      setUploadSuccess(true);
      setUploadProgress(100);
      
      setZipProgress({
        status: 'success',
        message: '✓ ZIP package ready for download',
        filePath,
      });
      
      await refetch();
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error during upload';
      console.error('ZIP upload error:', errorMessage);
      
      setZipProgress({
        status: 'error',
        message: `Upload failed: ${errorMessage}`,
        filePath,
      });
    } finally {
      setIsUploading(false);
    }
  }, [uploadZip, refetch]);

  useEffect(() => {
    if (window.electronAPI?.onZipProgress) {
      const unsubscribe = window.electronAPI.onZipProgress((progress) => {
        setZipProgress(progress);
        setIsCreating(progress.status === 'creating');
        
        if (progress.status === 'success' && progress.filePath && !isUploading && !uploadSuccess) {
          setBuiltZipPath(progress.filePath);
          handleUploadZip(progress.filePath).catch((err) => {
            console.error('Auto-upload error:', err);
          });
        }
      });
      return unsubscribe;
    }
  }, [handleUploadZip, isUploading, uploadSuccess]);

  const handleCreateZip = async () => {
    if (!window.electronAPI?.createProjectZip) {
      setZipProgress({
        status: 'error',
        message: 'ZIP creation not available - please run in Electron desktop app',
      });
      return;
    }
    
    setIsCreating(true);
    setUploadProgress(0);
    setUploadSuccess(false);
    setBuiltZipPath(null);
    
    setZipProgress({
      status: 'creating',
      message: 'Starting ZIP creation...',
    });

    try {
      await window.electronAPI.createProjectZip();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('ZIP creation error:', errorMessage);
      setZipProgress({
        status: 'error',
        message: `ZIP creation failed: ${errorMessage}`,
      });
      setIsCreating(false);
    }
  };

  const handleDownload = async () => {
    if (!zipFile) return;
    
    setIsDownloading(true);
    
    try {
      const directUrl = zipFile.getDirectURL();
      const link = document.createElement('a');
      link.href = directUrl;
      link.download = 'Virtual-DJ-Studio-Project.zip';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        setIsDownloading(false);
      }, 100);
    } catch (err) {
      console.error('Download error:', err);
      setIsDownloading(false);
    }
  };

  const handleRefresh = async () => {
    try {
      await refetch();
    } catch (err) {
      console.error('Refetch error:', err);
    }
  };

  const isElectron = typeof window !== 'undefined' && window.electronAPI !== undefined;

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-lg text-blue-900 dark:text-blue-100">Project ZIP Archive</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          Complete project source code with all dependencies, build scripts, and documentation. 
          Perfect for developers who want to customize or build the installer locally.
        </AlertDescription>
      </Alert>

      {zipProgress.status !== 'idle' && (
        <Alert
          variant={zipProgress.status === 'error' ? 'destructive' : 'default'}
          className={
            zipProgress.status === 'success' && uploadSuccess
              ? 'border-green-500 bg-green-50 dark:bg-green-950'
              : ''
          }
        >
          {(zipProgress.status === 'creating' || isUploading) && (
            <Loader2 className="h-5 w-5 animate-spin" />
          )}
          {zipProgress.status === 'success' && uploadSuccess && (
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          )}
          {zipProgress.status === 'error' && (
            <AlertCircle className="h-5 w-5" />
          )}
          <AlertDescription className="ml-2 text-base">
            {zipProgress.message}
          </AlertDescription>
        </Alert>
      )}

      {(isCreating || isUploading) && (
        <div className="space-y-2">
          <Progress 
            value={isUploading ? uploadProgress : undefined} 
            className="h-3" 
          />
          <p className="text-sm text-muted-foreground text-center">
            {isUploading 
              ? `Uploading ZIP to backend... ${uploadProgress}%` 
              : 'Creating ZIP archive... This may take 1-2 minutes.'}
          </p>
        </div>
      )}

      {isElectron && (
        <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-lg border border-primary/20">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-semibold mb-1">Create Project ZIP</h3>
              <p className="text-sm text-muted-foreground">Package entire project for distribution</p>
            </div>
            <Package className="h-12 w-12 text-primary opacity-50" />
          </div>
          
          <Button 
            variant="default" 
            size="lg" 
            className="w-full gap-2 text-lg py-6"
            onClick={handleCreateZip}
            disabled={isCreating || isUploading}
          >
            {isCreating || isUploading ? (
              <>
                <Loader2 className="h-6 w-6 animate-spin" />
                {isUploading ? 'Uploading...' : 'Creating ZIP...'}
              </>
            ) : (
              <>
                <Package className="h-6 w-6" />
                Generate & Upload Project ZIP
              </>
            )}
          </Button>
        </div>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-3 text-lg">Checking for latest ZIP archive...</span>
        </div>
      )}

      {error && (
        <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
          <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
          <AlertTitle className="text-red-900 dark:text-red-100">Error Loading ZIP</AlertTitle>
          <AlertDescription className="text-red-800 dark:text-red-200">
            <p className="mb-3">Unable to fetch ZIP archive from backend. Please try again.</p>
            <Button variant="outline" size="sm" onClick={handleRefresh}>
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {!isLoading && !error && zipFile && (
        <div className="space-y-4">
          <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
            <AlertTitle className="text-green-900 dark:text-green-100">
              ✓ ZIP package available for download
            </AlertTitle>
            <AlertDescription className="text-green-800 dark:text-green-200">
              Latest version includes complete source code and build tools.
            </AlertDescription>
          </Alert>

          <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-lg border border-primary/20">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-1">Virtual DJ Studio Project</h3>
                <p className="text-sm text-muted-foreground">Complete source code • Build scripts • Documentation</p>
              </div>
              <FileArchive className="h-12 w-12 text-primary opacity-50" />
            </div>
            
            <Button 
              variant="default" 
              size="lg" 
              className="w-full gap-2 text-lg py-6"
              onClick={handleDownload}
              disabled={isDownloading}
            >
              {isDownloading ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  Starting Download...
                </>
              ) : (
                <>
                  <Download className="h-6 w-6" />
                  Download ZIP Package
                </>
              )}
            </Button>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <p className="font-semibold mb-2 flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              What's Included:
            </p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Complete React + TypeScript frontend source code</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Electron main process and preload scripts</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>All dependencies (package.json and package-lock.json)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>One-click "Build Installer" script for local installer generation</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>Complete documentation and setup instructions</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span>All visual assets and branding files</span>
              </li>
            </ul>
          </div>

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Terminal className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">Quick Start</AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <p className="mb-2">After extracting the ZIP:</p>
              <pre className="bg-background p-3 rounded border text-xs font-mono mb-2">
                <code>{`npm install
cd frontend && npm install && cd ..
cd frontend && npm run build && cd ..
npm run build:win`}</code>
              </pre>
              <p className="text-sm">Your installer will be in <code className="bg-background px-1 rounded">dist-electron/</code></p>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {!isLoading && !error && !zipFile && (
        <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
          <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          <AlertTitle className="text-amber-900 dark:text-amber-100">No ZIP Available</AlertTitle>
          <AlertDescription className="text-amber-800 dark:text-amber-200 space-y-3">
            <p>The project ZIP has not been uploaded yet. {isElectron ? 'Use the button above to create and upload the ZIP package.' : 'The ZIP package needs to be created and uploaded from the Electron desktop app.'}</p>
            <Button variant="outline" size="sm" onClick={handleRefresh}>
              Check Again
            </Button>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
