import { useEffect, useRef, useState } from 'react';
import { Play, Pause, RotateCcw, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import Waveform from './Waveform';
import Turntable from './Turntable';
import EQControls from './EQControls';
import { AudioEngine } from '../lib/audioEngine';

interface DeckProps {
  deckId: 'A' | 'B';
  audioEngine: AudioEngine;
  expertMode: boolean;
}

export default function Deck({ deckId, audioEngine, expertMode }: DeckProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [trackName, setTrackName] = useState<string | null>(null);
  const [volume, setVolume] = useState(75);
  const [tempo, setTempo] = useState(100);
  const [pitch, setPitch] = useState(0);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [cuePoints, setCuePoints] = useState<number[]>([]);
  const [loopStart, setLoopStart] = useState<number | null>(null);
  const [loopEnd, setLoopEnd] = useState<number | null>(null);

  useEffect(() => {
    const deck = audioEngine.getDeck(deckId);
    
    const updateProgress = () => {
      if (deck.audioElement) {
        setProgress(deck.audioElement.currentTime);
        setDuration(deck.audioElement.duration || 0);
      }
    };

    const interval = setInterval(updateProgress, 50);
    return () => clearInterval(interval);
  }, [audioEngine, deckId]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Please select a valid audio file (MP3 or WAV)');
      return;
    }

    try {
      await audioEngine.loadTrack(deckId, file);
      setTrackName(file.name);
      setProgress(0);
      setCuePoints([]);
      setLoopStart(null);
      setLoopEnd(null);
      toast.success(`Loaded: ${file.name}`);
    } catch (error) {
      toast.error('Failed to load track');
      console.error(error);
    }
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      audioEngine.pause(deckId);
      setIsPlaying(false);
    } else {
      audioEngine.play(deckId);
      setIsPlaying(true);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const vol = value[0];
    setVolume(vol);
    audioEngine.setVolume(deckId, vol / 100);
  };

  const handleTempoChange = (value: number[]) => {
    const newTempo = value[0];
    setTempo(newTempo);
    audioEngine.setTempo(deckId, newTempo / 100);
  };

  const handlePitchChange = (value: number[]) => {
    const newPitch = value[0];
    setPitch(newPitch);
    audioEngine.setPitch(deckId, newPitch);
  };

  const addCuePoint = () => {
    const deck = audioEngine.getDeck(deckId);
    if (deck.audioElement) {
      const currentTime = deck.audioElement.currentTime;
      setCuePoints([...cuePoints, currentTime]);
      toast.success(`Cue point added at ${currentTime.toFixed(2)}s`);
    }
  };

  const setLoopIn = () => {
    const deck = audioEngine.getDeck(deckId);
    if (deck.audioElement) {
      setLoopStart(deck.audioElement.currentTime);
      toast.success('Loop start set');
    }
  };

  const setLoopOut = () => {
    const deck = audioEngine.getDeck(deckId);
    if (deck.audioElement && loopStart !== null) {
      const end = deck.audioElement.currentTime;
      setLoopEnd(end);
      audioEngine.setLoop(deckId, loopStart, end);
      toast.success('Loop enabled');
    }
  };

  const clearLoop = () => {
    audioEngine.clearLoop(deckId);
    setLoopStart(null);
    setLoopEnd(null);
    toast.success('Loop cleared');
  };

  const handleWaveformSeek = (time: number) => {
    audioEngine.seek(deckId, time);
    setProgress(time);
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-card to-accent/10">
        <CardTitle className="flex items-center justify-between">
          <span>Deck {deckId}</span>
          <Button
            size="sm"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Load Track
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/mp3,audio/wav,audio/mpeg"
            onChange={handleFileUpload}
            className="hidden"
          />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 p-4">
        {/* Track Info */}
        <div className="rounded-lg bg-muted/50 p-3 text-center">
          <p className="truncate text-sm font-medium">
            {trackName || 'No track loaded'}
          </p>
          {duration > 0 && (
            <p className="text-xs text-muted-foreground">
              {formatTime(progress)} / {formatTime(duration)}
            </p>
          )}
        </div>

        {/* Turntable */}
        <Turntable isPlaying={isPlaying} />

        {/* Waveform */}
        <Waveform
          audioEngine={audioEngine}
          deckId={deckId}
          progress={progress}
          duration={duration}
          cuePoints={cuePoints}
          loopStart={loopStart}
          loopEnd={loopEnd}
          onSeek={handleWaveformSeek}
        />

        {/* Play Controls */}
        <div className="flex items-center justify-center gap-2">
          <Button
            size="lg"
            variant={isPlaying ? 'secondary' : 'default'}
            onClick={togglePlayPause}
            disabled={!trackName}
            className="relative h-16 w-16 overflow-hidden rounded-full p-0"
          >
            {isPlaying ? (
              <img
                src="/assets/generated/pause-button-transparent.dim_64x64.png"
                alt="Pause"
                className="h-full w-full object-contain"
              />
            ) : (
              <img
                src="/assets/generated/play-button-transparent.dim_64x64.png"
                alt="Play"
                className="h-full w-full object-contain"
              />
            )}
          </Button>
        </div>

        {/* Volume Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-xs">Volume</Label>
            <span className="text-xs text-muted-foreground">{volume}%</span>
          </div>
          <div className="relative">
            <Slider
              value={[volume]}
              onValueChange={handleVolumeChange}
              max={100}
              step={1}
              className="w-full"
            />
          </div>
        </div>

        {/* Expert Mode Controls */}
        {expertMode && (
          <>
            {/* Tempo Control */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Tempo</Label>
                <span className="text-xs text-muted-foreground">{tempo}%</span>
              </div>
              <Slider
                value={[tempo]}
                onValueChange={handleTempoChange}
                min={50}
                max={150}
                step={1}
                className="w-full"
              />
            </div>

            {/* Pitch Control */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Pitch</Label>
                <span className="text-xs text-muted-foreground">
                  {pitch > 0 ? '+' : ''}{pitch}
                </span>
              </div>
              <Slider
                value={[pitch]}
                onValueChange={handlePitchChange}
                min={-12}
                max={12}
                step={1}
                className="w-full"
              />
            </div>

            {/* EQ Controls */}
            <EQControls audioEngine={audioEngine} deckId={deckId} />

            {/* Loop & Cue Controls */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={addCuePoint}
                disabled={!trackName}
                className="relative overflow-hidden"
              >
                <img
                  src="/assets/generated/cue-button.dim_80x80.png"
                  alt="Cue"
                  className="absolute inset-0 h-full w-full object-contain opacity-20"
                />
                <span className="relative z-10">Add Cue</span>
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={setLoopIn}
                disabled={!trackName}
              >
                Loop In
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={setLoopOut}
                disabled={!trackName || loopStart === null}
              >
                Loop Out
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={clearLoop}
                disabled={loopStart === null}
              >
                <RotateCcw className="mr-1 h-3 w-3" />
                Clear Loop
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function formatTime(seconds: number): string {
  if (!isFinite(seconds)) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
