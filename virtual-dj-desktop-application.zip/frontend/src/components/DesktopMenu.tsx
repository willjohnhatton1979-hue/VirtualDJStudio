import { Maximize2, Minimize2, Monitor } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface DesktopMenuProps {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onSetWindowed: () => void;
}

export default function DesktopMenu({
  isFullscreen,
  onToggleFullscreen,
  onSetWindowed,
}: DesktopMenuProps) {
  return (
    <div className="border-b border-border/50 bg-card/30 backdrop-blur-sm">
      <div className="container mx-auto flex h-10 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs">
                View
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={onToggleFullscreen}>
                {isFullscreen ? (
                  <>
                    <Minimize2 className="mr-2 h-4 w-4" />
                    Exit Fullscreen
                  </>
                ) : (
                  <>
                    <Maximize2 className="mr-2 h-4 w-4" />
                    Enter Fullscreen
                  </>
                )}
                <span className="ml-auto text-xs text-muted-foreground">F11</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onSetWindowed}>
                <Monitor className="mr-2 h-4 w-4" />
                Windowed Mode
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="text-xs text-muted-foreground">
          {isFullscreen ? 'Fullscreen Mode' : 'Windowed Mode'} • Press F11 to toggle
        </div>
      </div>
    </div>
  );
}
