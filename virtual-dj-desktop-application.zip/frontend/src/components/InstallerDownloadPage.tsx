import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Download, Info, CheckCircle2, Terminal, ExternalLink, Package, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { useGetInstaller } from '../hooks/useQueries';
import { useState } from 'react';

export function InstallerDownloadPage() {
  const { data: installer, isLoading, error, refetch } = useGetInstaller();
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = () => {
    if (!installer) {
      return;
    }
    
    setIsDownloading(true);
    
    try {
      // Use the direct URL from ExternalBlob for immediate download
      const directUrl = installer.getDirectURL();
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = directUrl;
      link.download = 'Virtual-DJ-Studio-Setup-1.0.0.exe';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      setTimeout(() => {
        document.body.removeChild(link);
        setIsDownloading(false);
      }, 100);
      
    } catch (err) {
      // Silently handle download errors - user will see browser's download UI
      setIsDownloading(false);
    }
  };

  const handleRetry = () => {
    refetch();
  };

  const getDownloadsPath = () => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (userAgent.includes('win')) {
      return 'C:\\Users\\[YourUsername]\\Downloads\\Virtual-DJ-Studio-Setup-1.0.0.exe';
    } else if (userAgent.includes('mac')) {
      return '~/Downloads/Virtual-DJ-Studio-Setup-1.0.0.exe';
    }
    return 'Downloads/Virtual-DJ-Studio-Setup-1.0.0.exe';
  };

  const getFileSizeDisplay = () => {
    return '~150-200 MB';
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-8 text-center">
        <h1 className="text-5xl font-bold mb-4">Download Virtual DJ Studio</h1>
        <p className="text-xl text-muted-foreground">
          Professional dual-deck mixing for Windows 11
        </p>
      </div>

      <Alert className="mb-8 border-blue-500 bg-blue-50 dark:bg-blue-950">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-lg text-blue-900 dark:text-blue-100">Secure Backend Storage</AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          Virtual DJ Studio uses an automated build and upload system. The latest Windows installer 
          is automatically generated, uploaded to secure backend storage, and made available with a 
          direct download link. The installer is verified and ready for immediate download.
        </AlertDescription>
      </Alert>

      <Card className="mb-8 border-2 border-primary shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-3xl">
            <Download className="h-8 w-8 text-primary" />
            Download for Windows 11
          </CardTitle>
          <CardDescription className="text-base">
            Ready-to-install package for Windows 10/11 (64-bit)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-3 text-lg">Checking for latest installer...</span>
            </div>
          )}

          {error && (
            <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
              <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
              <AlertTitle className="text-red-900 dark:text-red-100">Error Loading Installer</AlertTitle>
              <AlertDescription className="text-red-800 dark:text-red-200">
                <p className="mb-3">Unable to fetch installer information from the backend. This could be due to:</p>
                <ul className="list-disc list-inside space-y-1 mb-4 text-sm">
                  <li>Network connectivity issues</li>
                  <li>Backend temporarily unavailable</li>
                  <li>Installer not yet uploaded</li>
                </ul>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRetry}
                  className="gap-2 border-red-600 text-red-900 dark:text-red-100 hover:bg-red-100 dark:hover:bg-red-900"
                >
                  <RefreshCw className="h-4 w-4" />
                  Retry
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {!isLoading && !error && installer && (
            <div className="space-y-4">
              <Alert className="border-green-500 bg-green-50 dark:bg-green-950 shadow-sm">
                <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-900 dark:text-green-100">✓ Installer ready – click below to download Virtual DJ Studio for Windows 11</AlertTitle>
                <AlertDescription className="text-green-800 dark:text-green-200">
                  <p className="mb-2">
                    The latest installer is available and ready for immediate download.
                  </p>
                  <p className="text-xs">
                    The installer is securely hosted with a direct download link. Click the button below to start downloading.
                  </p>
                </AlertDescription>
              </Alert>

              <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-lg border border-primary/20">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold mb-1">Virtual DJ Studio Setup</h3>
                    <p className="text-sm text-muted-foreground">Version 1.0.0 • Windows 10/11 (64-bit) • {getFileSizeDisplay()}</p>
                  </div>
                  <Package className="h-12 w-12 text-primary opacity-50" />
                </div>
                
                <Button 
                  variant="default" 
                  size="lg" 
                  className="w-full gap-2 text-lg py-6 shadow-md hover:shadow-lg transition-shadow"
                  onClick={handleDownload}
                  disabled={isDownloading}
                >
                  {isDownloading ? (
                    <>
                      <Loader2 className="h-6 w-6 animate-spin" />
                      Starting Download...
                    </>
                  ) : (
                    <>
                      <Download className="h-6 w-6" />
                      Download for Windows 11
                    </>
                  )}
                </Button>

                <p className="text-xs text-center text-muted-foreground mt-3">
                  Direct download link • Automatically saves to your Downloads folder
                </p>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <p className="font-semibold mb-2">Installer Details:</p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>Application:</strong> Virtual DJ Studio v1.0.0</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>Format:</strong> NSIS Windows Installer (.exe)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>File Size:</strong> {getFileSizeDisplay()} (includes Electron runtime)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>Platform:</strong> Windows 10/11 (64-bit)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>Display:</strong> Fullscreen by default, resizable with F11 toggle</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                    <span><strong>Status:</strong> Verified and ready for download</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {!isLoading && !error && !installer && (
            <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
              <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              <AlertTitle className="text-amber-900 dark:text-amber-100">No Installer Available Yet</AlertTitle>
              <AlertDescription className="text-amber-800 dark:text-amber-200">
                <p className="mb-3">
                  The installer has not been uploaded to the backend yet. To make the installer available:
                </p>
                <ul className="list-disc list-inside space-y-1 mb-4 text-sm">
                  <li>Use the Electron desktop application to build and upload the installer</li>
                  <li>The system will automatically upload and make it available here</li>
                  <li>Or follow the build instructions below to create it locally</li>
                </ul>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRetry}
                  className="gap-2 border-amber-600 text-amber-900 dark:text-amber-100 hover:bg-amber-100 dark:hover:bg-amber-900"
                >
                  <RefreshCw className="h-4 w-4" />
                  Check Again
                </Button>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card className="mb-8 border-2 border-blue-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Info className="h-6 w-6 text-blue-600" />
            Step-by-Step Installation Guide
          </CardTitle>
          <CardDescription className="text-base">
            Complete instructions for installing Virtual DJ Studio on Windows 11
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold text-lg mb-2">Step 1: Download the Installer</h3>
              <p className="text-sm text-muted-foreground">
                Click the "Download for Windows 11" button above. Your browser will automatically save the file to your Downloads folder 
                (typically C:\Users\YourName\Downloads). You may see a download progress indicator in your browser.
              </p>
            </div>

            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold text-lg mb-2">Step 2: Locate the Downloaded File</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Open your Downloads folder and look for a file named:
              </p>
              <pre className="bg-muted p-3 rounded text-xs border font-mono">Virtual-DJ-Studio-Setup-1.0.0.exe</pre>
              <p className="text-xs text-muted-foreground mt-2">
                Tip: Press <kbd className="px-2 py-1 bg-background border rounded font-mono">Win + E</kbd> to open File Explorer, then click "Downloads" in the left sidebar.
              </p>
            </div>

            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold text-lg mb-2">Step 3: Run the Installer</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Double-click the .exe file to start the installation wizard. If Windows SmartScreen appears:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Click "More info" link</li>
                <li>Then click "Run anyway" button</li>
                <li>This is normal for new applications not yet widely distributed</li>
              </ul>
            </div>

            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold text-lg mb-2">Step 4: Complete Installation</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Follow the installation wizard:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Accept the license agreement</li>
                <li>Choose installation location (default is recommended)</li>
                <li>Select whether to create a Desktop shortcut</li>
                <li>Click "Install" and wait for completion (usually takes 1-2 minutes)</li>
              </ul>
            </div>

            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="font-semibold text-lg mb-2 text-green-700 dark:text-green-400">Step 5: Launch Virtual DJ Studio</h3>
              <p className="text-sm text-muted-foreground mb-2">
                After installation completes:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Find "Virtual DJ Studio" in your Start Menu</li>
                <li>Or use the Desktop shortcut if you created one</li>
                <li>The app will launch in fullscreen mode by default</li>
                <li>Press <kbd className="px-2 py-1 bg-background border rounded text-xs font-mono">F11</kbd> to toggle fullscreen, or use the menu for windowed mode</li>
              </ul>
            </div>
          </div>

          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950">
            <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-900 dark:text-blue-100">System Requirements</AlertTitle>
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <ul className="list-disc list-inside space-y-1 text-sm mt-2">
                <li>Windows 10 or Windows 11 (64-bit)</li>
                <li>4 GB RAM minimum (8 GB recommended)</li>
                <li>500 MB free disk space</li>
                <li>Audio output device (speakers or headphones)</li>
                <li>1920x1080 resolution or higher recommended</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Package className="h-6 w-6" />
              What's Included
            </CardTitle>
            <CardDescription className="text-base">
              Professional DJ features out of the box
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Dual Turntable Interface</strong> - Independent Deck A and Deck B with realistic vinyl visualization</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Professional Mixer</strong> - Crossfader, master volume, and dual VU meters</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>3-Band EQ</strong> - Low, mid, and high frequency control per deck</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Waveform Display</strong> - Visual feedback with cue points and loop markers</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Tempo & Pitch Control</strong> - Real-time speed and pitch adjustment</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Loop & Cue System</strong> - Mark and jump to specific track positions</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>Expert Mode</strong> - Toggle between basic and advanced controls</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                <span><strong>4K Display Support</strong> - Optimized for high-DPI screens</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Terminal className="h-6 w-6 text-primary" />
              Build Your Own
            </CardTitle>
            <CardDescription className="text-base">
              Generate the installer locally with automated build scripts
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Prefer to build the installer yourself? Follow our automated build process to generate 
              a fresh installer on your local machine with full control over the build environment.
            </p>
            <Button 
              variant="outline" 
              size="lg" 
              className="w-full gap-2"
              onClick={() => {
                const buildSection = document.getElementById('build-instructions');
                buildSection?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              <Terminal className="h-5 w-5" />
              View Build Instructions
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8" id="build-instructions">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Terminal className="h-6 w-6" />
            Automated Build Process
          </CardTitle>
          <CardDescription className="text-base">
            Generate your Windows installer with these simple commands
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert className="border-amber-500 bg-amber-50 dark:bg-amber-950">
            <Info className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            <AlertTitle className="text-amber-900 dark:text-amber-100">Prerequisites</AlertTitle>
            <AlertDescription className="text-amber-800 dark:text-amber-200">
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Windows 10 or Windows 11 (64-bit)</li>
                <li>Node.js 18+ (<a href="https://nodejs.org" target="_blank" rel="noopener noreferrer" className="underline font-medium">download here</a>)</li>
                <li>Project source code from repository</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg mb-3">Step 1: Install Dependencies</h3>
              <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm border font-mono">
                <code>{`npm install
cd frontend && npm install && cd ..`}</code>
              </pre>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Step 2: Build Frontend</h3>
              <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm border font-mono">
                <code>{`cd frontend && npm run build && cd ..`}</code>
              </pre>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Step 3: Generate Windows Installer</h3>
              <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm border font-mono">
                <code>{`npm run build:win`}</code>
              </pre>
              <p className="text-sm text-muted-foreground mt-2">
                This command automatically packages the application with Electron Builder and creates 
                a professional NSIS installer with all branding assets.
              </p>
            </div>

            <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
              <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
              <AlertTitle className="text-green-900 dark:text-green-100">Output Location</AlertTitle>
              <AlertDescription className="text-green-800 dark:text-green-200">
                <p className="mb-2">After successful build, find your installer at:</p>
                <pre className="bg-background p-3 rounded border text-xs font-mono">
                  <code>dist-electron/Virtual DJ Studio Setup 1.0.0.exe</code>
                </pre>
                <p className="mt-3 text-sm">
                  The installer is ready to distribute and includes automatic Start Menu integration, 
                  optional Desktop shortcut, and complete uninstaller functionality.
                </p>
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <ExternalLink className="h-6 w-6" />
            Distribution Options
          </CardTitle>
          <CardDescription className="text-base">
            Share your installer with users worldwide
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 hover:border-primary transition-colors">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <ExternalLink className="h-4 w-4 text-primary" />
                GitHub Releases
              </h4>
              <p className="text-sm text-muted-foreground">
                Upload to GitHub repository releases for version-controlled distribution with 
                permanent download links and automatic update notifications.
              </p>
            </div>

            <div className="border rounded-lg p-4 hover:border-primary transition-colors">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <ExternalLink className="h-4 w-4 text-primary" />
                Cloud Storage
              </h4>
              <p className="text-sm text-muted-foreground">
                Host on Google Drive, Dropbox, OneDrive, or Mega with shareable links for 
                easy access and large file support.
              </p>
            </div>

            <div className="border rounded-lg p-4 hover:border-primary transition-colors">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <ExternalLink className="h-4 w-4 text-primary" />
                Web Hosting
              </h4>
              <p className="text-sm text-muted-foreground">
                Deploy to your own web server or CDN for direct downloads with custom domain 
                and full control over distribution.
              </p>
            </div>

            <div className="border rounded-lg p-4 hover:border-primary transition-colors">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <ExternalLink className="h-4 w-4 text-primary" />
                File Transfer Services
              </h4>
              <p className="text-sm text-muted-foreground">
                Use WeTransfer, SendGB, or similar services for temporary sharing and 
                quick distribution without account requirements.
              </p>
            </div>
          </div>

          <div className="mt-6 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
              Automatic Update Support
            </h4>
            <p className="text-sm text-blue-800 dark:text-blue-200">
              The installer is configured with electron-builder's automatic update system. 
              When you release new versions through GitHub Releases or your own update server, 
              users will be notified automatically and can update with one click.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="mt-8 text-center">
        <p className="text-muted-foreground mb-4">
          Need help with the build process or distribution?
        </p>
        <Button variant="outline" size="lg" asChild>
          <a
            href="https://caffeine.ai"
            target="_blank"
            rel="noopener noreferrer"
            className="gap-2"
          >
            <ExternalLink className="h-5 w-5" />
            Visit caffeine.ai for Support
          </a>
        </Button>
      </div>
    </div>
  );
}
