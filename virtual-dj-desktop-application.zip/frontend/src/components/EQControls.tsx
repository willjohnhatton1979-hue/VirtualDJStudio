import { useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { AudioEngine } from '../lib/audioEngine';

interface EQControlsProps {
  audioEngine: AudioEngine;
  deckId: 'A' | 'B';
}

export default function EQControls({ audioEngine, deckId }: EQControlsProps) {
  const [low, setLow] = useState(0);
  const [mid, setMid] = useState(0);
  const [high, setHigh] = useState(0);

  const handleLowChange = (value: number[]) => {
    const val = value[0];
    setLow(val);
    audioEngine.setEQ(deckId, 'low', val);
  };

  const handleMidChange = (value: number[]) => {
    const val = value[0];
    setMid(val);
    audioEngine.setEQ(deckId, 'mid', val);
  };

  const handleHighChange = (value: number[]) => {
    const val = value[0];
    setHigh(val);
    audioEngine.setEQ(deckId, 'high', val);
  };

  return (
    <div className="space-y-3 rounded-lg border border-border bg-card/50 p-3">
      <Label className="text-xs font-semibold">Equalizer</Label>
      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-2">
          <Label className="text-xs text-muted-foreground">Low</Label>
          <Slider
            value={[low]}
            onValueChange={handleLowChange}
            min={-12}
            max={12}
            step={1}
            orientation="vertical"
            className="h-24"
          />
          <span className="block text-center text-xs text-muted-foreground">
            {low > 0 ? '+' : ''}{low}dB
          </span>
        </div>
        <div className="space-y-2">
          <Label className="text-xs text-muted-foreground">Mid</Label>
          <Slider
            value={[mid]}
            onValueChange={handleMidChange}
            min={-12}
            max={12}
            step={1}
            orientation="vertical"
            className="h-24"
          />
          <span className="block text-center text-xs text-muted-foreground">
            {mid > 0 ? '+' : ''}{mid}dB
          </span>
        </div>
        <div className="space-y-2">
          <Label className="text-xs text-muted-foreground">High</Label>
          <Slider
            value={[high]}
            onValueChange={handleHighChange}
            min={-12}
            max={12}
            step={1}
            orientation="vertical"
            className="h-24"
          />
          <span className="block text-center text-xs text-muted-foreground">
            {high > 0 ? '+' : ''}{high}dB
          </span>
        </div>
      </div>
    </div>
  );
}
