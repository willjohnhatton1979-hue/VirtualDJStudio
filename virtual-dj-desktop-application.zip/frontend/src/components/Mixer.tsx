import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { AudioEngine } from '../lib/audioEngine';

interface MixerProps {
  audioEngine: AudioEngine;
  expertMode: boolean;
}

export default function Mixer({ audioEngine, expertMode }: MixerProps) {
  const [crossfader, setCrossfader] = useState(50);
  const [masterVolume, setMasterVolume] = useState(80);
  const [vuLevelA, setVuLevelA] = useState(0);
  const [vuLevelB, setVuLevelB] = useState(0);
  const animationRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    // Animate VU meters based on audio levels
    const updateVuMeters = () => {
      const deckA = audioEngine.getDeck('A');
      const deckB = audioEngine.getDeck('B');

      // Calculate VU levels based on playback state and volume
      let levelA = 0;
      let levelB = 0;

      if (deckA.audioElement && !deckA.audioElement.paused) {
        // Simulate audio level with some variation
        const baseLevel = deckA.gainNode?.gain.value || 0;
        levelA = baseLevel * (0.7 + Math.random() * 0.3) * 100;
      }

      if (deckB.audioElement && !deckB.audioElement.paused) {
        const baseLevel = deckB.gainNode?.gain.value || 0;
        levelB = baseLevel * (0.7 + Math.random() * 0.3) * 100;
      }

      // Apply crossfader influence
      const crossfaderPos = crossfader / 100;
      const gainA = Math.cos(crossfaderPos * Math.PI / 2);
      const gainB = Math.sin(crossfaderPos * Math.PI / 2);

      setVuLevelA(levelA * gainA);
      setVuLevelB(levelB * gainB);

      animationRef.current = requestAnimationFrame(updateVuMeters);
    };

    updateVuMeters();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [audioEngine, crossfader]);

  const handleCrossfaderChange = (value: number[]) => {
    const val = value[0];
    setCrossfader(val);
    audioEngine.setCrossfader(val / 100);
  };

  const handleMasterVolumeChange = (value: number[]) => {
    const val = value[0];
    setMasterVolume(val);
    audioEngine.setMasterVolume(val / 100);
  };

  return (
    <Card className="h-full w-full">
      <CardHeader className="bg-gradient-to-b from-accent/20 to-card">
        <CardTitle className="text-center">Mixer</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        {/* VU Meters */}
        <div className="space-y-2">
          <Label className="text-sm font-semibold">VU Meters</Label>
          <div className="flex items-center justify-center gap-4">
            {/* Deck A VU Meter */}
            <div className="relative flex flex-col items-center">
              <div className="relative h-48 w-28">
                <img
                  src="/assets/generated/vu-meter.dim_120x200.png"
                  alt="VU Meter A"
                  className="h-full w-full object-contain"
                />
                {/* Animated overlay for VU level */}
                <div className="absolute inset-0 flex items-end justify-center overflow-hidden">
                  <div
                    className="w-16 bg-gradient-to-t from-accent via-primary to-destructive opacity-60 transition-all duration-75"
                    style={{ height: `${Math.min(vuLevelA, 100)}%` }}
                  />
                </div>
              </div>
              <span className="mt-1 text-xs font-medium text-muted-foreground">
                Deck A
              </span>
            </div>

            {/* Deck B VU Meter */}
            <div className="relative flex flex-col items-center">
              <div className="relative h-48 w-28">
                <img
                  src="/assets/generated/vu-meter.dim_120x200.png"
                  alt="VU Meter B"
                  className="h-full w-full object-contain"
                />
                {/* Animated overlay for VU level */}
                <div className="absolute inset-0 flex items-end justify-center overflow-hidden">
                  <div
                    className="w-16 bg-gradient-to-t from-accent via-primary to-destructive opacity-60 transition-all duration-75"
                    style={{ height: `${Math.min(vuLevelB, 100)}%` }}
                  />
                </div>
              </div>
              <span className="mt-1 text-xs font-medium text-muted-foreground">
                Deck B
              </span>
            </div>
          </div>
        </div>

        {/* Crossfader */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold">Crossfader</Label>
          <div className="relative rounded-lg bg-muted/50 p-4">
            <div className="mb-3 flex justify-between text-xs text-muted-foreground">
              <span className={crossfader < 30 ? 'font-bold text-foreground' : ''}>
                Deck A
              </span>
              <span className={crossfader > 70 ? 'font-bold text-foreground' : ''}>
                Deck B
              </span>
            </div>
            
            {/* Crossfader with image background */}
            <div className="relative flex items-center justify-center">
              <img
                src="/assets/generated/crossfader-horizontal.dim_200x60.png"
                alt="Crossfader"
                className="absolute h-12 w-full object-contain opacity-30"
              />
              <Slider
                value={[crossfader]}
                onValueChange={handleCrossfaderChange}
                max={100}
                step={1}
                className="relative z-10 w-full"
              />
            </div>
            
            <div className="mt-3 text-center text-xs text-muted-foreground">
              {crossfader < 30 && 'A Dominant'}
              {crossfader >= 30 && crossfader <= 70 && 'Balanced'}
              {crossfader > 70 && 'B Dominant'}
            </div>
          </div>
        </div>

        {/* Master Volume */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-semibold">Master Volume</Label>
            <span className="text-xs text-muted-foreground">{masterVolume}%</span>
          </div>
          <div className="flex justify-center">
            <div className="relative flex items-center gap-4">
              {/* Volume knob image */}
              <div className="relative h-24 w-24">
                <img
                  src="/assets/generated/master-volume-knob.dim_100x100.png"
                  alt="Master Volume"
                  className="h-full w-full object-contain"
                  style={{
                    transform: `rotate(${(masterVolume / 100) * 270 - 135}deg)`,
                    transition: 'transform 0.2s ease-out',
                  }}
                />
              </div>
              
              {/* Vertical slider */}
              <Slider
                value={[masterVolume]}
                onValueChange={handleMasterVolumeChange}
                max={100}
                step={1}
                orientation="vertical"
                className="h-48"
              />
              
              {/* Visual indicator */}
              <div className="relative h-48 w-3 overflow-hidden rounded-full bg-muted">
                <div
                  className="absolute bottom-0 w-full bg-gradient-to-t from-accent via-primary to-destructive transition-all duration-200"
                  style={{ 
                    height: `${masterVolume}%`
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
