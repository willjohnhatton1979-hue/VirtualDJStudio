import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { ExternalBlob, ReleaseMetadata } from '../backend';

// Release type constants matching backend
const RELEASE_TYPES = {
  installer: 'installer',
  zip: 'zip',
  githubRelease: 'githubRelease',
} as const;

// Hook to get the latest installer from backend
export function useGetInstaller() {
  const { actor, isFetching } = useActor();

  return useQuery<ExternalBlob | null>({
    queryKey: ['installer'],
    queryFn: async () => {
      if (!actor) return null;
      try {
        const result = await actor.getLatestFile(RELEASE_TYPES.installer);
        return result;
      } catch (error) {
        // Log error but don't throw - let React Query handle it
        if (error instanceof Error) {
          throw new Error(`Failed to fetch installer: ${error.message}`);
        }
        throw new Error('Failed to fetch installer: Unknown error');
      }
    },
    enabled: !!actor && !isFetching,
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 2,
  });
}

// Hook to get the latest ZIP from backend
export function useGetZip() {
  const { actor, isFetching } = useActor();

  return useQuery<ExternalBlob | null>({
    queryKey: ['zip'],
    queryFn: async () => {
      if (!actor) return null;
      try {
        const result = await actor.getLatestFile(RELEASE_TYPES.zip);
        return result;
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Failed to fetch ZIP: ${error.message}`);
        }
        throw new Error('Failed to fetch ZIP: Unknown error');
      }
    },
    enabled: !!actor && !isFetching,
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 2,
  });
}

// Hook to get all GitHub releases metadata
export function useGetGitHubReleases() {
  const { actor, isFetching } = useActor();

  return useQuery<Array<[bigint, ReleaseMetadata]>>({
    queryKey: ['github-releases'],
    queryFn: async () => {
      if (!actor) return [];
      try {
        const allMetadata = await actor.getAllReleaseMetadata();
        // Filter for GitHub releases only
        return allMetadata.filter(([_, metadata]) => metadata.releaseType === RELEASE_TYPES.githubRelease);
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Failed to fetch GitHub releases: ${error.message}`);
        }
        throw new Error('Failed to fetch GitHub releases: Unknown error');
      }
    },
    enabled: !!actor && !isFetching,
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 2,
  });
}

// Hook to upload installer to backend
export function useUploadInstaller() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (installer: ExternalBlob) => {
      if (!actor) {
        throw new Error('Backend not initialized. Please refresh the page.');
      }
      
      try {
        const version = BigInt(Date.now());
        
        await actor.uploadRelease(
          version,
          RELEASE_TYPES.installer,
          installer,
          'Virtual DJ Studio Windows Installer',
          'Professional Windows 11 installer with NSIS packaging, automatic Start Menu integration, and complete uninstaller functionality.',
          'VirtualDJStudio-Setup.exe'
        );
        
        // Wait for backend to process
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        return { success: true, version };
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Upload failed: ${error.message}`);
        }
        throw new Error('Upload failed: Unknown error');
      }
    },
    onSuccess: async () => {
      try {
        await queryClient.invalidateQueries({ queryKey: ['installer'] });
        await queryClient.refetchQueries({ queryKey: ['installer'] });
      } catch (error) {
        // Silently handle refetch errors - data will be stale but app continues
      }
    },
    retry: 1,
  });
}

// Hook to upload ZIP to backend
export function useUploadZip() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (zipFile: ExternalBlob) => {
      if (!actor) {
        throw new Error('Backend not initialized. Please refresh the page.');
      }
      
      try {
        const version = BigInt(Date.now());
        await actor.uploadRelease(
          version,
          RELEASE_TYPES.zip,
          zipFile,
          'Virtual DJ Studio Project ZIP',
          'Complete project source code with all dependencies, build scripts, and documentation. Includes one-click "Build Installer" script for local installer generation.',
          'VirtualDJStudio-Project.zip'
        );
        
        // Wait for backend to process
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        return { success: true, version };
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Upload failed: ${error.message}`);
        }
        throw new Error('Upload failed: Unknown error');
      }
    },
    onSuccess: async () => {
      try {
        await queryClient.invalidateQueries({ queryKey: ['zip'] });
        await queryClient.refetchQueries({ queryKey: ['zip'] });
      } catch (error) {
        // Silently handle refetch errors - data will be stale but app continues
      }
    },
    retry: 1,
  });
}

// Hook to save GitHub release metadata to backend
export function useUploadGitHubRelease() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ releaseUrl, version, filename }: { releaseUrl: string; version: bigint; filename: string }) => {
      if (!actor) {
        throw new Error('Backend not initialized. Please refresh the page.');
      }
      
      try {
        // Create a placeholder blob with the release URL
        const urlBytes = new TextEncoder().encode(releaseUrl);
        const blob = ExternalBlob.fromBytes(urlBytes);
        
        await actor.uploadRelease(
          version,
          RELEASE_TYPES.githubRelease,
          blob,
          `Virtual DJ Studio v${version.toString()}`,
          `GitHub Release: ${releaseUrl}`,
          filename
        );
        
        return { success: true, version, releaseUrl };
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Failed to save release: ${error.message}`);
        }
        throw new Error('Failed to save release: Unknown error');
      }
    },
    onSuccess: async () => {
      try {
        await queryClient.invalidateQueries({ queryKey: ['github-releases'] });
        await queryClient.refetchQueries({ queryKey: ['github-releases'] });
      } catch (error) {
        // Silently handle refetch errors - data will be stale but app continues
      }
    },
    retry: 1,
  });
}
