export interface Deck {
  audioElement: HTMLAudioElement | null;
  audioBuffer: AudioBuffer | null;
  gainNode: GainNode | null;
  lowEQ: BiquadFilterNode | null;
  midEQ: BiquadFilterNode | null;
  highEQ: BiquadFilterNode | null;
  sourceNode: MediaElementAudioSourceNode | null;
}

export class AudioEngine {
  private audioContext: AudioContext;
  private deckA: Deck;
  private deckB: Deck;
  private crossfaderGainA: GainNode;
  private crossfaderGainB: GainNode;
  private masterGain: GainNode;

  constructor() {
    this.audioContext = new AudioContext();
    
    // Initialize master gain
    this.masterGain = this.audioContext.createGain();
    this.masterGain.connect(this.audioContext.destination);
    this.masterGain.gain.value = 0.8;

    // Initialize crossfader gains
    this.crossfaderGainA = this.audioContext.createGain();
    this.crossfaderGainB = this.audioContext.createGain();
    this.crossfaderGainA.connect(this.masterGain);
    this.crossfaderGainB.connect(this.masterGain);

    // Initialize decks
    this.deckA = this.createDeck();
    this.deckB = this.createDeck();

    // Set initial crossfader position (center)
    this.setCrossfader(0.5);
  }

  private createDeck(): Deck {
    return {
      audioElement: null,
      audioBuffer: null,
      gainNode: null,
      lowEQ: null,
      midEQ: null,
      highEQ: null,
      sourceNode: null,
    };
  }

  getDeck(deckId: 'A' | 'B'): Deck {
    return deckId === 'A' ? this.deckA : this.deckB;
  }

  async loadTrack(deckId: 'A' | 'B', file: File): Promise<void> {
    const deck = this.getDeck(deckId);
    const crossfaderGain = deckId === 'A' ? this.crossfaderGainA : this.crossfaderGainB;

    // Clean up existing audio
    if (deck.audioElement) {
      deck.audioElement.pause();
      deck.audioElement.src = '';
    }

    // Create new audio element
    const audio = new Audio();
    audio.src = URL.createObjectURL(file);
    deck.audioElement = audio;

    // Load audio buffer for waveform
    const arrayBuffer = await file.arrayBuffer();
    deck.audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);

    // Create audio nodes
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    deck.sourceNode = this.audioContext.createMediaElementSource(audio);
    deck.gainNode = this.audioContext.createGain();
    deck.gainNode.gain.value = 0.75;

    // Create EQ filters
    deck.lowEQ = this.audioContext.createBiquadFilter();
    deck.lowEQ.type = 'lowshelf';
    deck.lowEQ.frequency.value = 320;
    deck.lowEQ.gain.value = 0;

    deck.midEQ = this.audioContext.createBiquadFilter();
    deck.midEQ.type = 'peaking';
    deck.midEQ.frequency.value = 1000;
    deck.midEQ.Q.value = 0.5;
    deck.midEQ.gain.value = 0;

    deck.highEQ = this.audioContext.createBiquadFilter();
    deck.highEQ.type = 'highshelf';
    deck.highEQ.frequency.value = 3200;
    deck.highEQ.gain.value = 0;

    // Connect nodes
    deck.sourceNode
      .connect(deck.lowEQ)
      .connect(deck.midEQ)
      .connect(deck.highEQ)
      .connect(deck.gainNode)
      .connect(crossfaderGain);
  }

  play(deckId: 'A' | 'B'): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume();
      }
      deck.audioElement.play();
    }
  }

  pause(deckId: 'A' | 'B'): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      deck.audioElement.pause();
    }
  }

  setVolume(deckId: 'A' | 'B', volume: number): void {
    const deck = this.getDeck(deckId);
    if (deck.gainNode) {
      deck.gainNode.gain.value = volume;
    }
  }

  setTempo(deckId: 'A' | 'B', tempo: number): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      deck.audioElement.playbackRate = tempo;
    }
  }

  setPitch(deckId: 'A' | 'B', semitones: number): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      // Pitch shift using playback rate (approximation)
      const rate = Math.pow(2, semitones / 12);
      deck.audioElement.playbackRate = rate;
    }
  }

  setEQ(deckId: 'A' | 'B', band: 'low' | 'mid' | 'high', gain: number): void {
    const deck = this.getDeck(deckId);
    if (band === 'low' && deck.lowEQ) {
      deck.lowEQ.gain.value = gain;
    } else if (band === 'mid' && deck.midEQ) {
      deck.midEQ.gain.value = gain;
    } else if (band === 'high' && deck.highEQ) {
      deck.highEQ.gain.value = gain;
    }
  }

  setCrossfader(position: number): void {
    // Position: 0 = full A, 0.5 = center, 1 = full B
    const gainA = Math.cos(position * Math.PI / 2);
    const gainB = Math.sin(position * Math.PI / 2);
    
    this.crossfaderGainA.gain.value = gainA;
    this.crossfaderGainB.gain.value = gainB;
  }

  setMasterVolume(volume: number): void {
    this.masterGain.gain.value = volume;
  }

  setLoop(deckId: 'A' | 'B', start: number, end: number): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      const audio = deck.audioElement;
      
      const checkLoop = () => {
        if (audio.currentTime >= end) {
          audio.currentTime = start;
        }
      };

      audio.addEventListener('timeupdate', checkLoop);
    }
  }

  clearLoop(deckId: 'A' | 'B'): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      // Remove all timeupdate listeners by cloning the element
      const oldAudio = deck.audioElement;
      const newAudio = oldAudio.cloneNode(true) as HTMLAudioElement;
      newAudio.currentTime = oldAudio.currentTime;
      if (!oldAudio.paused) {
        newAudio.play();
      }
      deck.audioElement = newAudio;
    }
  }

  seek(deckId: 'A' | 'B', time: number): void {
    const deck = this.getDeck(deckId);
    if (deck.audioElement) {
      deck.audioElement.currentTime = time;
    }
  }
}
